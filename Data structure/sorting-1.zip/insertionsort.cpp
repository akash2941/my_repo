#include<iostream>
using namespace std;
void insertion(int *,int);
int main()
{
	int N;
	cin>>N;
	int arr[N];
	for(int i=0;i<N;i++){
		cin>>arr[i];
	}
	cout<<"Before sort"<<endl;
	for(int i=0;i<N;i++){
		cout<<arr[i]<<" ";
	}
	cout<<endl;
	insertion(arr,N);
	cout<<"After sort"<<endl;
	for(int i=0;i<N;i++){
		cout<<arr[i]<<" ";
	}
return 0;
}

void insertion(int *arr,int size){
	
	for(int i=1;i<size;i++){
		int temp=arr[i];
		int j=i-1;
		while(j>=0 && arr[j]>temp){
			arr[j+1]=arr[j];
			j=j-1;
		}
		arr[j+1]=temp;
	}
}
